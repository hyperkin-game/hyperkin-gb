#ifndef CIL_RESET_AST_H_
#define CIL_RESET_AST_H_

#include "cil_tree.h"

int cil_reset_ast(struct cil_tree_node *current);

#endif /* CIL_RESET_AST_H_ */
