#ifndef EXEC_CIA_H
#define EXEC_CIA_H

int exec_cia(const char* path, const char** args);

#endif