#ifndef LIBRETRO_MPV_VERSION
#define LIBRETRO_MPV_VERSION "0.3.alpha"
#endif
