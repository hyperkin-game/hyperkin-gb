#include <selinux/get_default_type.h>
#include "dso.h"

hidden_proto(selinux_default_type_path)
