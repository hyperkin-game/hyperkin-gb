#!/bin/sh

autoreconf --force --install --verbose
